package com.simplilearn.Jfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
